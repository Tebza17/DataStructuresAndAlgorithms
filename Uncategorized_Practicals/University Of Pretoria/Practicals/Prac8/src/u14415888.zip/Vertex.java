/**
 * Name: Teboho Mokoena
 * Student Number: u14415888
 */
public class Vertex {
    private Integer value = Integer.MAX_VALUE;
    public Vertex(Integer value) {
        // TODO: your code here...
        this.value = value;
    }

    /**
     * Return the value of the vertex
     */
    public Integer getValue() {
        // TODO: your code here...
        return value;
    }
}